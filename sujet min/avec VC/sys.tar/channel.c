#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <sys/mman.h>
#include <semaphore.h>

#include "channel.h"

/*definir les erreurs */
#define ECREATE 0
#define EALLOC  1
#define EDEST   2
#define ECLOSE  3
#define ESEND   4



/*declaration de la methode channel_create */
/* le channel est ouvert ---> closed = 0 si il est fermer closed = 1 */
struct mandel_reply {
    short int x, y;
    short int count;
    short int data[100];
};

struct channel *channel_create(int eltsize, int size, int flags){

	struct channel *canel = malloc(sizeof(channel1));
	if(canel == NULL){
		errno = ECREATE;
		exit(-1);
	}		
	canel->size = size;
	printf("size = %d \n",canel->size);
	canel->eltsize = eltsize;
	canel->closed = 0;

	canel->data = mmap(NULL, eltsize*size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, -1, 0);
	if(canel->data == MAP_FAILED)
		{
			errno = EALLOC;
			return NULL;
		}

	canel->pread = canel->data;
	canel->pwrite = canel->data;

	sem_init(&canel->sem_full, CHANNEL_PROCESS_SHARED, canel->size); 
    sem_init(&canel->sem_empty, CHANNEL_PROCESS_SHARED, 0);
	pthread_mutex_init(&canel->verrou, NULL);
	return canel;
}
/*declaration de la methode destroy */
void channel_destroy(struct channel *channel){
	if(channel != NULL){
		free(channel);
		}
	else{
		errno = EDEST;
		exit(-1);
		}
}
/*declaration de la methode channel_send */
int channel_send(struct channel *channel, const void *data){

	
struct mandel_reply *toutou = (struct mandel_reply*) channel->pwrite;

	if(channel->closed == 1){
		errno = EPIPE; 
		return -1;
		
	}	

	printf("send data %d\n", toutou->x);

		
	

    int rc = sem_wait(&channel->sem_full);
    if ( rc < 0 ) {
        perror("sem_wait");
        exit(EXIT_FAILURE);
    }
		pthread_mutex_lock(&channel->verrou);
		printf("je suis aprés le sem \n");
		memcpy(channel->pwrite, data, channel->eltsize);
		printf("je suis aprés memcpy \n");

		if(channel->pwrite == (channel->data +(channel->eltsize * (channel->size - 1)))){
			channel->pwrite = channel->data;
		}else{
			channel->pwrite = channel->pwrite + channel->eltsize;
		}
	pthread_mutex_unlock(&channel->verrou);
	rc = sem_post(&channel->sem_empty);
	
    return 1;
				
}
/*declaration de la methode channel_close */
int channel_close(struct channel *channel){
	switch(channel->closed){
	case 1 :
						return 0;
	case 0 :{
					  channel->closed = 1;
					  return 1;
					}
default : {
						errno = ECLOSE;	
						return -1;
					}
		}
}
/*declaration de la methode channel_recv*/
int channel_recv(struct channel *channel, void *data){
	
 
	if(channel->closed == 1){
		return 0;
	}
	

	
    int rc = sem_wait(&channel->sem_empty);
    if ( rc < 0 ) {
        perror("sem_post");
        exit(EXIT_FAILURE);
    }
		pthread_mutex_lock(&channel->verrou);
		memcpy(data, channel->pread, channel->eltsize);
		
		if(channel->pread == (channel->data +(channel->eltsize * (channel->size - 1)))){
			channel->pread = channel->data;
		}else{
			channel->pread = channel->pread + channel->eltsize;
		}

		struct mandel_reply *toutou = (struct mandel_reply*) data;
    printf("received%d\n", toutou->x);
		pthread_mutex_unlock(&channel->verrou);
		rc = sem_post(&channel->sem_full);
		
		
		
	
	return 1;
}
/*int main(){
	struct channel *p = channel_create(sizeof(int), 10, 0);
	printf("le size est %d \n",p->size);
	void *data;
  data = mmap(NULL, p->eltsize,PROT_READ | PROT_WRITE,MAP_SHARED | MAP_ANONYMOUS,-1, 0);
	
	int entier = 3;
	memcpy(p->data , &entier , p->eltsize);
	void *d;
	d = mmap(NULL, p->eltsize,PROT_READ | PROT_WRITE,MAP_SHARED | MAP_ANONYMOUS,-1, 0);
	
	memcpy(d, p->data , p->eltsize);
	
    int *seddik = (int *)d;
	printf("la valeur est %d \n",*seddik);
		
	return EXIT_SUCCESS;
}*/
